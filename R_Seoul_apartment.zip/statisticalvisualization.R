# 관심 지역 데이터만 추출하기
# 필요한 패키지를 로드하고, 작업 디렉토리를 설정합니다.
# 저장된 데이터 파일(apt_price.rdata, kde_high.rdata, seoul.shp)을 불러옵니다.
# sf 패키지를 사용하여 지리 정보를 포함한 데이터를 다룰 수 있는 객체로 변환합니다.
# 데이터 시각화를 위해 tmap 패키지를 사용합니다.
# 관심 지역과 전체 지역을 결합하고 필요한 데이터를 추출합니다.
# 결과 데이터를 저장하고 메모리를 정리합니다.
# 
# 전체 지역과 관심 지역의 평당 가격 데이터를 불러옵니다.
# 밀도 그래프를 그리기 위해 필요한 값들을 계산합니다.
# ggplot2 패키지를 사용하여 전체 지역과 관심 지역의 확률 밀도 함수를 시각화합니다.
# 회귀분석으로 월별 평당 거래가를 요약합니다.
# 회귀식을 모델링하고 회귀 계수를 계산합니다.
# 회귀분석 결과를 그래프로 시각화합니다.
# 주성분 분석을 수행합니다.
# 주성분 분석 결과를 그래프로 시각화합니다.
# 
# *참고*
# 회귀분석이란 통계학에서 사용되는 중요한 분석 방법 중 하나로, 변수 간의 관계를 이해하고 예측하는 데 사용
# 회귀식이란 종속 변수와 하나 이상의 독립 변수 간의 관계를 수학적으로 모델링한 식
# 회기계수이란 b는 독립 변수와 종속 변수 간의 관계를 나타내는 중요한 통계적 값
# 주성분 분석이란 주성분 분석은 다차원 데이터를 더 낮은 차원으로 축소하거나 데이터의 주요 패턴을 식별하는 통계적 기법

library(sf) 
setwd(dirname(rstudioapi::getSourceEditorContext()$path))
load("./geodataframe/apt_price.rdata")   
load("./map/kde_high.rdata")   
grid <- st_read("./code/sigun_grid/seoul.shp") 

library(tmap) 
tmap_mode('view')
tm_shape(grid) + tm_borders() + tm_text("ID", col = "red") + 
  tm_shape(raster_high) + 
  tm_raster(palette = c("blue", "green", "yellow","red"), alpha =.4) + 
  tm_basemap(server = c('OpenStreetMap'))

library(dplyr)
apt_price <-st_join(apt_price, grid, join = st_intersects)
apt_price <- apt_price %>% st_drop_geometry()             
all <- apt_price                      
sel <- apt_price %>% filter(ID == 81016)
dir.create("08_chart") 
save(all, file="./08_chart/all.rdata") 
save(sel, file="./08_chart/sel.rdata") 
rm(list = ls())

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
load("./08_chart/all.rdata")  
load("./08_chart/sel.rdata") 
max_all <- density(all$py) ; max_all <- max(max_all$y) 
max_sel <- density(sel$py) ; max_sel <- max(max_sel$y) 
plot_high <- max(max_all, max_sel) 
rm(list = c("max_all", "max_sel"))
avg_all <- mean(all$py)  
avg_sel <- mean(sel$py)  
avg_all ; avg_sel ; plot_high  

plot(stats::density(all$py), ylim=c(0, plot_high), 
  col="blue", lwd=3, main= NA) 
abline(v = mean(all$py), lwd = 2, col = "blue", lty=2)
text(avg_all + (avg_all) * 0.15, plot_high * 0.1, 
  sprintf("%.0f",avg_all), srt=0.2, col = "blue")  
lines(stats::density(sel$py), col="red", lwd=3)     
abline(v = avg_sel, lwd = 2, col = "red", lty=2)  
text(avg_sel + avg_sel * 0.15 , plot_high * 0.1, 
  sprintf("%.0f", avg_sel), srt=0.2, col = "red") 
rm(list = ls())

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
load("./08_chart/all.rdata")  
load("./08_chart/sel.rdata")  
library(dplyr)      
library(lubridate)  
all <- all %>% group_by(month=floor_date(ymd, "month")) %>% 
  summarize(all_py = mean(py))
sel <- sel %>% group_by(month=floor_date(ymd, "month")) %>% 
  summarize(sel_py = mean(py)) 

fit_all <- lm(all$all_py ~ all$month)   
fit_sel <- lm(sel$sel_py ~ sel$month)   
coef_all <- round(summary(fit_all)$coefficients[2], 1) * 365
coef_sel <- round(summary(fit_sel)$coefficients[2], 1) * 365

library(grid)  
grob_1 <- grobTree(textGrob(paste0("전체지역: ", coef_all, "만원(평당)"), x=0.05, 
                            y=0.88, hjust=0, gp=gpar(col="blue", fontsize=13, fontface="italic")))
grob_2 <- grobTree(textGrob(paste0("관심지역: ", coef_sel, "만원(평당)"), x=0.05,  
                            y=0.95, hjust=0, gp=gpar(col="red", fontsize=16, fontface="bold")))
library(ggpmisc)  
gg <- ggplot(sel, aes(x=month, y=sel_py)) + 
  geom_line() + xlab("월")+ ylab("가격") +
  theme(axis.text.x=element_text(angle=90)) + 
  stat_smooth(method='lm', colour="dark grey", linetype = "dashed") +
  theme_bw()
gg + geom_line(color= "red", size=1.5) +
  geom_line(data=all, aes(x=month, y=all_py), color="blue", size=1.5) +
  annotation_custom(grob_1) +
  annotation_custom(grob_2)
rm(list = ls())  

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
load("./08_chart/sel.rdata")  
pca_01 <- aggregate(list(sel$con_year, sel$floor, sel$py, sel$area), 
                    by=list(sel$apt_nm), mean) 
colnames(pca_01) <- c("apt_nm", "신축", "층수","가격", "면적")
m <- prcomp(~ 신축 + 층수 + 가격 + 면적, data= pca_01, scale=T) 
summary(m)

library(ggfortify)
autoplot(m, loadings.label=T, loadings.label.size=6)+
  geom_label(aes(label=pca_01$apt_nm), size=4)  