# setwd(dirname(rstudioapi::getSourceEditorContext()$path)): 현재 R 스크립트 파일이 위치한 디렉토리를 작업 디렉토리로 설정합니다.
# load("./preprocess/preprocess.rdata"): 미리 저장된 R 데이터 파일을 로드하여 아파트 거래 데이터를 불러옵니다.
# load("./geocoding/juso_geocoding.rdata"): 미리 저장된 R 데이터 파일을 로드하여 주소에서 좌표로 변환된 데이터를 불러옵니다.
# library(dplyr): dplyr 라이브러리를 로드합니다. *dplyr은R에서 데이터조작 변형을 수행하는데 사용하는 패키지*
# apt_price <- left_join(apt_price, juso_geocoding, by = c("juso_jibun" = "apt_juso")): 아파트 거래 데이터와 주소에서 좌표로 변환된 데이터를 좌표값을 기준으로 결합합니다.
# apt_price <- na.omit(apt_price): 결합 후 나타나는 결측값을 제거합니다.
# 
# 지오 데이터프레임 만들기
# library(sp): sp 라이브러리를 로드합니다. *sp는Spatial R에서 공간데이터를 처리하기위한 패키지중 하나*
# coordinates(apt_price) <- ~coord_x + coord_y: 좌표값을 지정합니다.
# proj4string(apt_price) <- "+proj=longlat +datum=WGS84 +no_defs": *좌표계(CRS)("Coordinate Reference System)좌표에서 지리적위치를 위미*  정보를 설정합니다.
# 
# apt_price <- st_as_sf(apt_price): sp 객체를 sf 객체로 변환합니다. 밑은 sp -> sf르 변환하는 이유 우리같은경우 시각화를 위해서변환합니다.
# 코드에서 sp를 sf로 변환하는 이유는 주로 sf 패키지가 더 효율적이며 직관적인 데이터 처리를 가능하게 하기 때문입니다. 
# sf 패키지는 R의 최신 공간 데이터 처리 방법을 채택하고 있으며, 더 많은 기능과 성능 향상을 제공합니다. 
# 따라서 공간 데이터를 다루는 경우, 가능하다면 sf 패키지를 사용하는 것이 좋습니다.
# 
# plot(apt_price$geometry, axes = T, pch = 1): 좌표 데이터를 포함한 지오 데이터프레임을 플롯으로 시각화합니다.
# library(leaflet): leaflet 라이브러리를 로드합니다. *웹페이지나 애플리케이션에 지도를 표시하고자 할때 사용됨.
# leaflet() %>% addTiles() %>% addCircleMarkers(data=apt_price[1:1000,], label=~apt_nm): 지도를 생성하고, 원 형태의 마커로 아파트 정보를 지도에 추가합니다.
# 
# save(apt_price, file="./geodataframe/apt_price.rdata"): R 데이터 파일로 지오 데이터프레임을 저장합니다.
# write.csv(apt_price, "./geodataframe/apt_price.csv"): CSV 파일로 지오 데이터프레임을 저장합니다.

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
load("./preprocess/preprocess.rdata")  
load("./geocoding/juso_geocoding.rdata") 

library(dplyr)
apt_price <- left_join(apt_price, juso_geocoding, 
                       by = c("juso_jibun" = "apt_juso"))
apt_price <- na.omit(apt_price) 

library(sp)
coordinates(apt_price) <- ~coord_x + coord_y  
proj4string(apt_price) <- "+proj=longlat +datum=WGS84 +no_defs" 
library(sf)
apt_price <- st_as_sf(apt_price)  

plot(apt_price$geometry, axes = T, pch = 1)     
library(leaflet)                          
leaflet() %>% 
  addTiles() %>% 
  addCircleMarkers(data=apt_price[1:1000,], label=~apt_nm)

dir.create("geodataframe")
save(apt_price, file="./geodataframe/apt_price.rdata") 
write.csv(apt_price, "./geodataframe/apt_price.csv")