# 작업 디렉토리 설정 및 지역 코드 데이터 읽기
# setwd 함수를 사용하여 작업 디렉토리를 설정합니다.
# "sigun_code.csv" 파일에서 지역 코드 데이터를 읽어옵니다.
# 
# 수집 기간 설정
# 시작 날짜에서 종료 날짜까지 월 단위로 날짜 목록을 생성합니다.
# 
# 요청 목록 생성 및 확인
# 여러 지역과 기간에 대한 데이터를 수집하기 위한 요청 목록을 생성합니다.
# 요청 목록을 확인하기 위해 첫 번째 요청을 웹 브라우저에서 엽니다.
# 
# 크롤링 실행
# 요청 목록을 기반으로 데이터를 크롤링하고 처리합니다.
# XML 응답 데이터를 임시 저장하고, 필요한 정보를 추출하여 데이터를 저장합니다.
# 
# 통합
# 크롤링한 데이터를 통합하고, 결과를 저장합니다.

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
getwd()

loc <- read.csv("./code/sigun_code/sigun_code.csv", fileEncoding="UTF-8")
loc$code <- as.character(loc$code)
head(loc, 2)

datelist <- seq(from = as.Date('2021-01-01'),
                to   = as.Date('2021-12-31'),
                by    = '1 month')           
datelist <- format(datelist, format = '%Y%m')
datelist[1:3]

service_key <- ""  # (본인)인증키 입력

url_list <- list() 
cnt <-0	    

for(i in 1:nrow(loc)){          
  for(j in 1:length(datelist)){
    cnt <- cnt + 1           
    url_list[cnt] <- paste0("http://openapi.molit.go.kr:8081/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTrade?",
                            "LAWD_CD=", loc[i,1],     
                            "&DEAL_YMD=", datelist[j],   
                            "&numOfRows=", 100,          
                            "&serviceKey=", service_key)  
  } 
  Sys.sleep(0.1)   
  msg <- paste0("[", i,"/",nrow(loc), "]  ", loc[i,3], " 의 크롤링 목록이 생성됨 => 총 [", cnt,"] 건")
  cat(msg, "\n\n") 
}

length(url_list)              
browseURL(paste0(url_list[1]))

library(XML)     
library(data.table) 
library(stringr)  

raw_data <- list()   
root_Node <- list()      
total <- list()         
dir.create("raw_data") 

for(i in 1:length(url_list)){   
  raw_data[[i]] <- xmlTreeParse(url_list[i], useInternalNodes = TRUE,encoding = "utf-8")
  root_Node[[i]] <- xmlRoot(raw_data[[i]])

  items <- root_Node[[i]][[2]][['items']] 
  size <- xmlSize(items)        
  
  item <- list() 
  item_temp_dt <- data.table()  
  Sys.sleep(.1) 
  for(m in 1:size){ 
    item_temp <- xmlSApply(items[[m]],xmlValue)
    item_temp_dt <- data.table(year = item_temp[4],  
                               month = item_temp[7],  
                               day = item_temp[8],      
                               price = item_temp[1],  
                               code = item_temp[12], 
                               dong_nm = item_temp[5], 
                               jibun = item_temp[11], 
                               con_year = item_temp[3], 
                               apt_nm = item_temp[6], 
                               area = item_temp[9],    
                               floor = item_temp[13])  
    item[[m]] <- item_temp_dt}    
  apt_bind <- rbindlist(item)    


  
  region_nm <- subset(loc, code== str_sub(url_list[i],115, 119))$addr_1
  month <- str_sub(url_list[i],130, 135) 
  path <- as.character(paste0("./raw_data/", region_nm, "_", month,".csv"))
  write.csv(apt_bind, path)
  msg <- paste0("[", i,"/",length(url_list), "] 수집한 데이터를 [", path,"]에 저장 합니다.")
  cat(msg, "\n\n")
}

setwd(dirname(rstudioapi::getSourceEditorContext()$path))  
files <- dir("./raw_data")
library(plyr)               
apt_price <- ldply(as.list(paste0("./raw_data/", files)), read.csv)
tail(apt_price, 2)

dir.create("./integrated")
save(apt_price, file = "./integrated/apt_price.rdata")
write.csv(apt_price, "./integrated/apt_price.csv")   

seq(from = as.Date('1990-01-01'), 
    to   = as.Date('2020-12-31'),
    by    = '1 year')            

for (i in 1:3) {   
  for (j in 1:3) {   
    Sys.sleep(0.1) 
    print(paste(i,j,sep=","))
  }
}

URL <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Frestaurants.xml" 
library(XML)        # install.packages("XML")   
file <- xmlTreeParse(sub("s", "", URL), useInternal = TRUE)  
file <- xmlToDataFrame(file)  
file <- as.data.frame(t(file))  
head(file)
