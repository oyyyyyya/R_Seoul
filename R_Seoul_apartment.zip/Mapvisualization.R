# 주소와 좌표 결합하기
# setwd(dirname(rstudioapi::getSourceEditorContext()$path)): 현재 R 스크립트 파일의 디렉토리를 작업 디렉토리로 설정합니다.
# load("./geodataframe/apt_price.rdata"): 사전에 저장된 지리 데이터를 불러옵니다.
# library(sf): 공간 데이터를 다루는 sf 패키지를 불러옵니다.
# grid <- st_read("./code/sigun_grid/seoul.shp"): 지도 그리드 데이터를 불러옵니다. * "그리드"는 지도 상의 격자 형태의 분할된 영역*
# 
# apt_price <- st_join(apt_price, grid, join = st_intersects): 아파트 가격 데이터와 지도 그리드를 공간적으로 결합합니다.
# head(apt_price): 결합된 데이터의 첫 부분을 출력합니다.
# 지오 데이터프레임 만들기 * 데이터프레임이 강조되는건 2차원 데이터구조 저희가 배운 R 데이터프레임을 생각하면 이해하기 편함 *
# sf 패키지를 사용하여 지오 데이터프레임을 생성하고 시각화합니다.
# 
# rm(list = ls()) 마지막에 메모리 초기화를 해주는데
# R은 대용량 데이터를 다르는 경우가 많아서 불필요한 메모리사용량이 증가할수있음 불필요한 객체제거하고 메모리관리 수행
# 변수충돌방지, 겹치는 변수가 있을수 있어 모두 삭제한다.정도로만 이해해주시면 될것같습니다.

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
load("./geodataframe/apt_price.rdata")
library(sf) 
grid <- st_read("./code/sigun_grid/seoul.shp")
apt_price <-st_join(apt_price, grid, join = st_intersects) # 실거래+그리드 결합
head(apt_price)

kde_high <- aggregate(apt_price$py, by=list(apt_price$ID), mean) # 그리드별 평균가격
colnames(kde_high) <- c("ID", "avg_price")
head(kde_high, 2) 

kde_high <- merge(grid, kde_high,  by="ID")
library(ggplot2)
library(dplyr)
kde_high %>% ggplot(aes(fill = avg_price)) + 
  geom_sf() + 
  scale_fill_gradient(low = "white", high = "red")


library(sp)
kde_high_sp <- as(st_geometry(kde_high), "Spatial") 
x <- coordinates(kde_high_sp)[,1]
y <- coordinates(kde_high_sp)[,2] 

l1 <- bbox(kde_high_sp)[1,1] - (bbox(kde_high_sp)[1,1]*0.0001)
l2 <- bbox(kde_high_sp)[1,2] + (bbox(kde_high_sp)[1,2]*0.0001)
l3 <- bbox(kde_high_sp)[2,1] - (bbox(kde_high_sp)[2,1]*0.0001)
l4 <- bbox(kde_high_sp)[2,2] + (bbox(kde_high_sp)[1,1]*0.0001)

library(spatstat)
win <- owin(xrange=c(l1,l2), yrange=c(l3,l4))
plot(win)

rm(list = c("kde_high_sp", "apt_price", "l1", "l2", "l3", "l4"))

p <- ppp(x, y, window=win)
d <- density.ppp(p, weights=kde_high$avg_price,
                 sigma = bw.diggle(p), 
                 kernel = 'gaussian')  
plot(d)
rm(list = c("x", "y", "win","p"))

d[d < quantile(d)[4] + (quantile(d)[4]*0.1)] <- NA
library(raster)
raster_high <- raster(d)
plot(raster_high)


bnd <- st_read("./code/sigun_bnd/seoul.shp")
raster_high <- crop(raster_high, extent(bnd)) 
crs(raster_high) <- sp::CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 + towgs84=0,0,0")
plot(raster_high) 
plot(bnd, col=NA, border = "red", add=TRUE)


library(rgdal)
library(leaflet)
leaflet() %>% 

  addProviderTiles(providers$CartoDB.Positron) %>% 

  addPolygons(data = bnd, weight = 3, color= "red", fill = NA) %>% 

  addRasterImage(raster_high, 
   colors = colorNumeric(c("blue", "green","yellow","red"), 
   values(raster_high), na.color = "transparent"), opacity = 0.4) 

dir.create("07_map")
save(raster_high, file="./07_map/kde_high.rdata")
rm(list = ls())

setwd(dirname(rstudioapi::getSourceEditorContext()$path)) 
load("./geodataframe/apt_price.rdata")   
grid <- st_read("./code/sigun_grid/seoul.shp") 
apt_price <-st_join(apt_price, grid, join = st_intersects)  
head(apt_price, 2)

kde_before <- subset(apt_price, ymd < "2021-07-01") 
kde_before <- aggregate(kde_before$py, by=list(kde_before$ID),mean)  
colnames(kde_before) <- c("ID", "before")

kde_after  <- subset(apt_price, ymd > "2021-07-01") 
kde_after <- aggregate(kde_after$py, by=list(kde_after$ID),mean) 
colnames(kde_after) <- c("ID", "after")

kde_diff <- merge(kde_before, kde_after, by="ID")  
kde_diff$diff <- round((((kde_diff$after-kde_diff$before)/
                           kde_diff$before)* 100), 0) 

head(kde_diff, 2)


library(sf)      
kde_diff <- kde_diff[kde_diff$diff > 0,]   
kde_hot <- merge(grid, kde_diff,  by="ID") 
library(ggplot2) 
library(dplyr)
kde_hot %>% 
  ggplot(aes(fill = diff)) + 
  geom_sf() + 
  scale_fill_gradient(low = "white", high = "red")


library(sp)
kde_hot_sp <- as(st_geometry(kde_hot), "Spatial")
x <- coordinates(kde_hot_sp)[,1] 
y <- coordinates(kde_hot_sp)[,2] 

l1 <- bbox(kde_hot_sp)[1,1] - (bbox(kde_hot_sp)[1,1]*0.0001) 
l2 <- bbox(kde_hot_sp)[1,2] + (bbox(kde_hot_sp)[1,2]*0.0001)
l3 <- bbox(kde_hot_sp)[2,1] - (bbox(kde_hot_sp)[2,1]*0.0001)
l4 <- bbox(kde_hot_sp)[2,2] + (bbox(kde_hot_sp)[1,1]*0.0001)

library(spatstat)
win <- owin(xrange=c(l1,l2), yrange=c(l3,l4))
plot(win)                                     
rm(list = c("kde_hot_sp", "apt_price", "l1", "l2", "l3", "l4"))


p <- ppp(x, y, window=win, marks=kde_hot$diff)
d <- density.ppp(p, weights=kde_hot$diff,   
                 sigma = bw.diggle(p), 
                 kernel = 'gaussian')
plot(d)   # 확인
rm(list = c("x", "y", "win","p"))

d[d < quantile(d)[4] + (quantile(d)[4]*0.1)] <- NA 
library(raster)         
raster_hot <- raster(d)
plot(raster_hot)


bnd <- st_read("./code/sigun_bnd/seoul.shp")
raster_hot <- crop(raster_hot, extent(bnd)) 
crs(raster_hot) <- sp::CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84  
                        +towgs84=0,0,0")
plot(raster_hot)
plot(bnd, col=NA, border = "red", add=TRUE)

library(leaflet)
leaflet() %>%
  addProviderTiles(providers$CartoDB.Positron) %>% 
  addPolygons(data = bnd, weight = 3, color= "red", fill = NA) %>% 
  addRasterImage(raster_hot, 
   colors = colorNumeric(c("blue", "green", "yellow","red"), 
   values(raster_hot), na.color = "transparent"), opacity = 0.4)

save(raster_hot, file="./07_map/kde_hot.rdata")
rm(list = ls()) 


setwd(dirname(rstudioapi::getSourceEditorContext()$path)) 
load("./geodataframe/apt_price.rdata")  
load("./07_map/kde_high.rdata")   
load("./07_map/kde_hot.rdata")   

library(sf)
bnd <- st_read("./code/sigun_bnd/seoul.shp")
grid <- st_read("./code/sigun_grid/seoul.shp")

pcnt_10 <- as.numeric(quantile(apt_price$py, probs = seq(.1, .9, by = .1))[1])
pcnt_90 <- as.numeric(quantile(apt_price$py, probs = seq(.1, .9, by = .1))[9])
load("./code/circle_marker/circle_marker.rdata")
circle.colors <- sample(x=c("red","green","blue"),size=1000, replace=TRUE)

library(purrr)
leaflet() %>% 
  addTiles() %>%  
  addPolygons(data = bnd, weight = 3, color= "red", fill = NA) %>%
  addRasterImage(raster_high, 
    colors = colorNumeric(c("blue","green","yellow","red"), values(raster_high), 
    na.color = "transparent"), opacity = 0.4, group = "2021 최고가") %>% 
  addRasterImage(raster_hot, 
    colors = colorNumeric(c("blue", "green", "yellow","red"), values(raster_hot), 
    na.color = "transparent"), opacity = 0.4, group = "2021 급등지") %>%   
  addLayersControl(baseGroups = c("2021 최고가", "2021 급등지"), options = layersControlOptions(collapsed = FALSE)) %>%
  addCircleMarkers(data = apt_price, lng =unlist(map(apt_price$geometry,1)), 
                   lat = unlist(map(apt_price$geometry,2)), radius = 10, stroke = FALSE, 
                   fillOpacity = 0.6, fillColor = circle.colors, weight=apt_price$py, 
                   clusterOptions = markerClusterOptions(iconCreateFunction=JS(avg.formula))) 

rm(list = ls())  