# 작업 디렉토리 설정 및 데이터 불러오기
# setwd(dirname(rstudioapi::getSourceEditorContext()$path)): 현재 R 스크립트 파일이 위치한 디렉토리를 작업 디렉토리로 설정합니다.
# load("./preprocess/preprocess.rdata"): 미리 저장된 R 데이터 파일을 호출하여 필요한 데이터를 불러옵니다.
# apt_juso <- data.frame(apt_price$juso_jibun): 아파트 거래 데이터에서 'juso_jibun' 열(주소 정보)을 데이터프레임으로 추출합니다.
# apt_juso <- data.frame(apt_juso[!duplicated(apt_juso), ]): 중복된 주소를 제거하여 고유한 주소만을 남깁니다.
# 
# add_list 및 cnt 변수: 결과를 저장하기 위한 빈 리스트 및 카운터 변수를 초기화합니다.
# 카카오 API를 사용하기 위한 인증 키를 설정합니다. (개인 정보를 포함한 실제 키로 대체해야 합니다)
# 
# 주소를 좌표로 변환하는 반복문
# for 루프를 사용하여 주소를 좌표로 변환합니다.
# GET 함수를 사용하여 주소를 좌표로 변환하는 API에 요청을 보냅니다.
# tryCatch를 사용하여 예외 처리를 수행하며, 오류가 발생하면 오류 메시지를 출력합니다.
# 변환된 좌표와 주소 정보를 add_list에 저장하고, 진행 상황 메시지를 출력합니다.
# 
# 지오코딩 결과 저장
# rbindlist를 사용하여 리스트를 데이터프레임으로 결합합니다.
# 좌표 열을 숫자로 변환하고 결측치를 제거합니다.
# 결과를 저장하기 위해 디렉토리를 생성하고, 결과를 R 데이터 파일 및 CSV 파일로 저장합니다.
# 
# 중복된 값 제거 및 웹 페이지 가져오기
# 중복된 값을 제거하고 고유한 제조사 이름을 확인합니다.
# 웹 페이지를 가져와 텍스트로 저장하고 일부 내용을 출력합니다.

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
load( "./preprocess/preprocess.rdata")     
apt_juso <- data.frame(apt_price$juso_jibun) 
apt_juso <- data.frame(apt_juso[!duplicated(apt_juso), ]) 
head(apt_juso, 2)  

add_list <- list() 
cnt <- 0          
kakao_key = ""       # (본인)인증키

library(httr)      
library(RJSONIO)  
library(data.table) 
library(dplyr)   

for(i in 1:nrow(apt_juso)){ 
  tryCatch(
    {
      lon_lat <- GET(url = 'https://dapi.kakao.com/v2/local/search/address.json',
                     query = list(query = apt_juso[i,]),
                     add_headers(Authorization = paste0("KakaoAK ", kakao_key)))
      coordxy <- lon_lat %>% content(as = 'text') %>% RJSONIO::fromJSON()
      cnt = cnt + 1
      add_list[[cnt]] <- data.table(apt_juso = apt_juso[i,], 
        coord_x = coordxy$documents[[1]]$x, 
        coord_y = coordxy$documents[[1]]$y)
      message <- paste0("[", i,"/",nrow(apt_juso),"] 번째 (", 
       round(i/nrow(apt_juso)*100,2)," %) [", apt_juso[i,] ,"] 지오코딩 중입니다: 
       X= ", add_list[[cnt]]$coord_x, " / Y= ", add_list[[cnt]]$coord_y)
      cat(message, "\n\n")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")}
  )
}

juso_geocoding <- rbindlist(add_list) 
juso_geocoding$coord_x <- as.numeric(juso_geocoding$coord_x) 
juso_geocoding$coord_y <- as.numeric(juso_geocoding$coord_y)
juso_geocoding <- na.omit(juso_geocoding)  
dir.create("./geocoding") 
save(juso_geocoding, file="./geocoding/juso_geocoding.rdata")
write.csv(juso_geocoding, "./geocoding/juso_geocoding.csv")

library(ggplot2)          
mpg <- data.frame(mpg$manufacturer)  
data.frame(mpg[!duplicated(mpg), ]) 

library(httr)  
library(rjson) 
library(dplyr)  

web_page <- GET('http://www.w3.org/Protocols/rfc2616/rfc2616.html') 
web_page <- web_page %>% content(as = 'text') 
head(web_page)   

inputs = list(1, 2, 3, 'four', 5, 6)

for(input in inputs) {  
  print(paste(input, "의 로그값은 =>", log(input)))
}

for(input in inputs) {  
  tryCatch({ 
    print(paste(input, "의 로그값은 =>", log(input)))
  }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")} )}