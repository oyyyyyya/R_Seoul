# 불필요한 정보 지우기
#   
# 코드는 현재 작업 디렉토리를 설정하고 경고 메시지를 숨깁니다.
# 저장된 실거래 데이터를 불러옵니다.
# 데이터에서 결측값을 확인하고 제거합니다.
# 문자열에서 공백을 제거하여 데이터를 정리합니다.
# 
# 항목별 데이터 다듬기
# 데이터 정제 과정을 다섯 단계로 분할합니다.
# 첫 번째 단계에서는 매매 연월일과 연월 데이터를 만들고, 두 번째 단계에서는 매매가를 확인합니다.
# 세 번째 단계에서는 주소 조합을 통해 주소 정보를 다듬고, 네 번째 단계에서는 건축 연도를 변환합니다.
# 다섯 번째 단계에서는 평당 매매가를 계산하고, 여섯 번째 단계에서는 층수를 변환합니다.
# 
# 저장하기
# 필요한 데이터 칼럼만 선택하고, 전처리가 완료된 데이터를 RData 및 CSV 형식으로 저장합니다.

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
options(warn=-1)

load("./integrated/apt_price.rdata") 
head(apt_price, 2)  

table(is.na(apt_price))        
apt_price <- na.omit(apt_price) 
table(is.na(apt_price))    

head(apt_price$price, 2)    

library(stringr)         
apt_price <- as.data.frame(apply(apt_price, 2, str_trim))
head(apt_price$price, 2)                                 

library(lubridate) 
library(dplyr)
apt_price <- apt_price %>% mutate(ymd=make_date(year, month, day)) 
apt_price$ym <- floor_date(apt_price$ymd, "month")                  
head(apt_price, 2)                                                

head(apt_price$price, 3)

apt_price$price <- apt_price$price %>% sub(",","",.) %>% as.numeric()
head(apt_price$price, 3)  

head(apt_price$apt_nm, 30)  

apt_price$apt_nm <- gsub("\\(.*","", apt_price$apt_nm) 
head(apt_price$apt_nm, 30)                          

loc <- read.csv("./code/sigun_code/sigun_code.csv", fileEncoding="UTF-8")  
apt_price <- merge(apt_price, loc, by = 'code')    
apt_price$juso_jibun <- paste0(apt_price$addr_2, " ", apt_price$dong," ",
                               apt_price$jibun," ",apt_price$apt_nm)
head(apt_price, 2)                        

head(apt_price$con_year, 3)

apt_price$con_year <- apt_price$con_year %>% as.numeric()  
head(apt_price$con_year, 3)

head(apt_price$area, 3)  

apt_price$area <- apt_price$area %>% as.numeric() %>% round(0) 
head(apt_price$area, 3)    

apt_price$py <- round(((apt_price$price/apt_price$area) * 3.3), 0)
head(apt_price$py, 3)

min(apt_price$floor)   

apt_price$floor <- apt_price$floor %>% as.numeric() %>% abs() 
min(apt_price$floor)

apt_price$cnt <- 1 
head(apt_price, 2)   

apt_price <- apt_price %>% select(ymd, ym, year, code, addr_1, apt_nm, 
              juso_jibun, price, con_year,  area, floor, py, cnt) 
head(apt_price, 2)

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
dir.create("./preprocess")  
save(apt_price, file = "./preprocess/preprocess.rdata") 
write.csv(apt_price, "./preprocess/preprocess.csv") 