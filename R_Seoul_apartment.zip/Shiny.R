# 샤이니 기본구조의 이해
# 
# 먼저 Shiny 라이브러리를 로드하고, Shiny 앱의 기본 구조를 설정합니다.
# Shiny 앱은 사용자 인터페이스(UI), 서버(Server), 그리고 shinyApp으로 구성됩니다.
# fluidPage 함수를 사용하여 사용자 인터페이스를 정의합니다.
# runExample 함수를 사용하여 Shiny가 제공하는 샘플 앱을 실행하고 확인합니다.
# 
# 01_hello 샘플의 사용자 인터페이스 부분
# 01_hello 샘플 앱의 사용자 인터페이스(UI) 부분을 구성합니다.
# fluidPage 내에서 제목 패널(titlePanel)과 레이아웃(sidebarLayout, mainPanel)을 정의합니다.
# 
# 01_hello 샘플의 서버 부분
# 01_hello 샘플 앱의 서버(Server) 부분을 구성합니다.
# renderPlot 함수를 사용하여 플롯을 렌더링하고, 사용자 입력값(input$bins)을 활용하여 히스토그램을 그립니다.
# 
# sliderInput 함수를 사용하여 사용자에게 연비 범위를 선택하도록 하는 입력 필드를 생성합니다.
# textOutput 함수를 사용하여 입력 값을 활용하여 출력 결과를 표시하도록 설정합니다.
# 
# DT와 ggplot2 라이브러리를 로드하고, mpg 데이터를 불러옵니다.
# 
# reactive * 사용자 입력 또는 다른 데이터에 대한 반응형 계산을 정의하는 데 사용되는 함수 *
# 를 사용하여 사용자 입력값(input$range)을 기반으로 데이터를 필터링합니다.
# 필터링된 데이터를 출력으로 반환합니다.

library(shiny)  
ui <- fluidPage("사용자 인터페이스")  
server <- function(input, output, session){} 
shinyApp(ui, server)  

library(shiny) 
runExample()    
runExample("01_hello")  

faithful <- faithful
head(faithful, 2)

library(shiny)       
ui <- fluidPage(    
  titlePanel("샤이니 1번 샘플"), 

  sidebarLayout(
    sidebarPanel(  
      sliderInput(inputId = "bins",      
                  label = "막대(bin)갯수:",   
                  min = 1, max = 50,        
                  value = 30)),           
    mainPanel( 
      plotOutput(outputId = "distPlot"))  
  ))

server <- function(input, output, session){
  output$distPlot <- renderPlot({
    x <- faithful$waiting 
    bins <- seq(min(x), max(x), length.out = input$bins + 1)
    hist(x, breaks = bins, col = "#75AADB", border = "white",
         xlab = "다음 분출때까지 대기시간(분)",  
         main = "대기시간 히스토그램")
  })
}

shinyApp(ui, server)
rm(list = ls()) 

library(shiny) 
ui <- fluidPage(   
  sliderInput("range", "연비", min = 0, max = 35, value = c(0, 10))) 

server <- function(input, output, session){}  

shinyApp(ui, server) 

library(shiny) 
ui <- fluidPage(
  sliderInput("range", "연비", min = 0, max = 35, value = c(0, 10)), 
  textOutput("value")) 

server <- function(input, output, session){
  output$value <- renderText((input$range[1] + input$range[2]))}

shinyApp(ui, server)

library(shiny) 
ui <- fluidPage(
  sliderInput("range", "연비", min = 0, max = 35, value = c(0, 10)),
  textOutput("value")) 

server <- function(input, output, session){
  output$value <- (input$range[1] + input$range[2])}  

shinyApp(ui, server)

library(DT)    
library(ggplot2) 
mpg <- mpg
head(mpg)

library(shiny) 
ui <- fluidPage(
  sliderInput("range", "연비", min = 0, max = 35, value = c(0, 10)),
  DT::dataTableOutput("table"))

server <- function(input, output, session){
  cty_sel = reactive({  
    cty_sel = subset(mpg, cty >= input$range[1] & cty <= input$range[2])
    return(cty_sel)})    
  output$table <- DT::renderDataTable(cty_sel()) }

shinyApp(ui, server)

library(shiny)
ui <- fluidPage(  
  fluidRow(    
    # 첫번째 열: 붉은색(red) 박스로 높이 450 픽셀, 폭 9
    column(9, div(style = "height:450px;border: 4px solid red;","폭 9")),
    # 두번째 열: 보라색(purple) 박스로 높이 450 픽셀, 폭 3
    column(3, div(style = "height:450px;border: 4px solid purple;","폭 3")),
    # 세번째 열: 파란색(blue) 박스로 높이 400 픽셀, 폭 12
    column(12, div(style = "height:400px;border: 4px solid blue;","폭 12"))))
server <- function(input, output, session) {}
shinyApp(ui, server)

library(shiny)
ui <- fluidPage(
  fluidRow(
    column(9, div(style = "height:450px;border: 4px solid red;","폭 9")),
    column(3, div(style = "height:450px;border: 4px solid red;","폭 3")),
    tabsetPanel(
      tabPanel("탭1",   
               column(4, div(style = "height:300px;border: 4px solid red;","폭 4")),
               column(4, div(style = "height:300px;border: 4px solid red;","폭 4")),           
               column(4, div(style = "height:300px;border: 4px solid red;","폭 4")), ),              
      tabPanel("탭2", div(style = "height:300px;border: 4px solid blue;","폭 12")))))
server <- function(input, output, session) {}
shinyApp(ui, server)